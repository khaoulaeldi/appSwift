//
//  Note.swift
//  AppFI
//
//  Created by pc on 01/07/2021.
//  Copyright © 2021 pc. All rights reserved.
//

import CoreData

@objc(Note)

class Note: NSManagedObject {
    @NSManaged var id: NSNumber!
    @NSManaged var title: String!
    @NSManaged var desc: String!
    
    @NSManaged var deletedDate: Date?
}
