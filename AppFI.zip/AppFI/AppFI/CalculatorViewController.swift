//
//  CalculatorViewController.swift
//  AppFI
//
//  Created by pc on 01/07/2021.
//  Copyright © 2021 pc. All rights reserved.
//

import UIKit


class CalculatorViewController: UIViewController {

    
    @IBOutlet weak var additionLabel: UILabel!
    @IBOutlet weak var pourboireLabel: UILabel!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    @IBAction func sliderValueChanged(_ sender: UISlider) {
        updateDisplay()
    }
    
    @IBAction func controlValueChanged(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            currencySign = "€"
        }else {
            currencySign = "MAD"
        }
        updateDisplay()
    }
    
    let tauxPourboire = 0.12
    var currencySign = "€"
    
    func updateDisplay(){
        let montantAddition  = slider.value
        
        let montantPourboire = Double(montantAddition) * tauxPourboire
        
        additionLabel.text = String(Int(montantAddition)) + "" + currencySign
        
        pourboireLabel.text = String(Int(montantPourboire)) + "" + currencySign
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        updateDisplay()
    }
    

   

}
