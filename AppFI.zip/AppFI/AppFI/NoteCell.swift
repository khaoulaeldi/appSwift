

import UIKit
import CoreData

class NoteCell: UITableViewCell {
    
    
    @IBOutlet weak var titleTF: UILabel!
    
    @IBOutlet weak var descTV: UILabel!
}
